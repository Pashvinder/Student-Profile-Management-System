/* =========================================================
   SPMS - MANAGE STUDENTS
   Beginner-friendly localStorage version.
   No backend and no React required.
   ========================================================= */


/* =========================================================
   CURRENT USER
   The signup/signin system stores the logged-in user as
   "currentUser". We use that same key here.
   ========================================================= */

var currentUser = JSON.parse(localStorage.getItem("currentUser"));

var isAdmin = false;

if (currentUser) {
    document.getElementById("profileName").textContent = "Hi, " + currentUser.name;
    document.getElementById("profileRole").textContent = currentUser.role || "User";

    if (currentUser.role && currentUser.role.toLowerCase() === "admin") {
        isAdmin = true;
    }
} else {
    document.getElementById("profileName").textContent = "Hi, Guest";
    document.getElementById("profileRole").textContent = "Guest";
}


/* =========================================================
   STUDENT DATA
   One student = one object.
   All objects are stored inside the "students" array.
   ========================================================= */

var students = JSON.parse(localStorage.getItem("students")) || [];

var currentPage = 1;
var studentsPerPage = 10;

var currentMode = "normal";
var pendingAction = null;
var generatedOTP = null;

var selectedStudents = [];


/* =========================================================
   ELEMENTS
   ========================================================= */

var studentList = document.getElementById("studentList");
var emptyState = document.getElementById("emptyState");
var studentCount = document.getElementById("studentCount");
var showingText = document.getElementById("showingText");

var studentSearch = document.getElementById("studentSearch");
var clearSearch = document.getElementById("clearSearch");
var branchFilter = document.getElementById("branchFilter");

var studentModal = document.getElementById("studentModal");
var otpModal = document.getElementById("otpModal");

var studentForm = document.getElementById("studentForm");

var removeBar = document.getElementById("removeBar");
var selectedCount = document.getElementById("selectedCount");
var removeNumber = document.getElementById("removeNumber");

var notAdmin = document.getElementById("notAdmin");

var addStudentBtn = document.getElementById("addStudentBtn");
var editStudentBtn = document.getElementById("editStudentBtn");
var removeStudentBtn = document.getElementById("removeStudentBtn");


/* =========================================================
   SAVE STUDENTS
   ========================================================= */

function saveStudents() {
    localStorage.setItem("students", JSON.stringify(students));
}


/* =========================================================
   ADMIN ACCESS
   ========================================================= */

function setupAdminAccess() {

    if (!isAdmin) {
        addStudentBtn.style.display = "none";
        editStudentBtn.style.display = "none";
        removeStudentBtn.style.display = "none";

        notAdmin.style.display = "block";
    }
}

setupAdminAccess();


/* =========================================================
   GET VALUE FROM FORM
   ========================================================= */

function getFormValue(id) {
    return document.getElementById(id).value.trim();
}


/* =========================================================
   CREATE STUDENT OBJECT
   ========================================================= */

function createStudentObject() {

    var student = {

        id: document.getElementById("studentId").value || Date.now().toString(),

        name: getFormValue("fullName"),
        rollNo: getFormValue("rollNo"),
        branch: getFormValue("branch"),
        cgpa: getFormValue("cgpa"),

        fatherName: getFormValue("fatherName"),
        motherName: getFormValue("motherName"),
        bloodGroup: getFormValue("bloodGroup"),
        category: getFormValue("category"),
        nationality: getFormValue("nationality"),
        address: getFormValue("address"),
        languages: getFormValue("languages"),

        tenth: getFormValue("tenth"),
        twelfth: getFormValue("twelfth"),
        backlogs: getFormValue("backlogs"),
        admissionYear: getFormValue("admissionYear"),
        graduationYear: getFormValue("graduationYear"),
        scholarship: getFormValue("scholarship"),
        hostel: getFormValue("hostel"),

        placementStatus: getFormValue("placementStatus"),
        companyPlaced: getFormValue("companyPlaced"),
        internship: getFormValue("internship"),
        resumeLink: getFormValue("resumeLink"),
        github: getFormValue("github"),
        portfolio: getFormValue("portfolio"),

        personality: getFormValue("personality"),
        favouriteSubject: getFormValue("favouriteSubject"),
        worstSubject: getFormValue("worstSubject"),
        dreamCompany: getFormValue("dreamCompany"),
        careerGoal: getFormValue("careerGoal"),
        hobbies: getFormValue("hobbies"),
        codingHandles: getFormValue("codingHandles"),
        codingRating: getFormValue("codingRating")
    };

    return student;
}


/* =========================================================
   OPEN ADD FORM
   ========================================================= */

addStudentBtn.addEventListener("click", function () {

    if (!isAdmin) return;

    currentMode = "add";

    studentForm.reset();

    document.getElementById("studentId").value = "";

    document.getElementById("formTitle").textContent = "Add Student";
    document.getElementById("submitText").textContent = "Save Student";

    studentModal.style.display = "flex";
});


/* =========================================================
   CLOSE FORM
   ========================================================= */

function closeStudentForm() {
    studentModal.style.display = "none";
}

document.getElementById("closeForm").addEventListener("click", closeStudentForm);
document.getElementById("cancelForm").addEventListener("click", closeStudentForm);


/* =========================================================
   EDIT MODE
   Clicking Edit changes the table into a selectable list.
   ========================================================= */

editStudentBtn.addEventListener("click", function () {

    if (!isAdmin) return;

    currentMode = "edit";
    selectedStudents = [];

    renderStudents();
});


/* =========================================================
   OPEN EDIT FORM
   ========================================================= */

function openEditForm(studentId) {

    var student = students.find(function (item) {
        return item.id === studentId;
    });

    if (!student) return;

    currentMode = "editing";

    document.getElementById("formTitle").textContent = "Edit Student";
    document.getElementById("submitText").textContent = "Update Student";

    fillForm(student);

    studentModal.style.display = "flex";
}


/* =========================================================
   PUT OLD STUDENT DATA INTO FORM
   ========================================================= */

function fillForm(student) {

    var fields = [
        "studentId",
        "fullName",
        "rollNo",
        "branch",
        "cgpa",
        "fatherName",
        "motherName",
        "bloodGroup",
        "category",
        "nationality",
        "address",
        "languages",
        "tenth",
        "twelfth",
        "backlogs",
        "admissionYear",
        "graduationYear",
        "scholarship",
        "hostel",
        "placementStatus",
        "companyPlaced",
        "internship",
        "resumeLink",
        "github",
        "portfolio",
        "personality",
        "favouriteSubject",
        "worstSubject",
        "dreamCompany",
        "careerGoal",
        "hobbies",
        "codingHandles",
        "codingRating"
    ];

    var studentKeys = {
        fullName: "name"
    };

    for (var i = 0; i < fields.length; i++) {

        var fieldId = fields[i];
        var objectKey = studentKeys[fieldId] || fieldId;

        var element = document.getElementById(fieldId);

        if (element) {
            element.value = student[objectKey] || "";
        }
    }
}


/* =========================================================
   FORM SUBMIT
   Add = directly creates the student.
   Edit = asks for OTP before changing data.
   ========================================================= */

studentForm.addEventListener("submit", function (e) {

    e.preventDefault();

    if (!isAdmin) return;

    var newStudent = createStudentObject();

    if (!newStudent.name || !newStudent.rollNo || !newStudent.branch) {
        alert("Please fill Full Name, Roll Number and Branch.");
        return;
    }


    /* ---------------- ADD ---------------- */

    if (currentMode === "add") {

        students.push(newStudent);
        saveStudents();

        closeStudentForm();
        renderStudents();

        alert("Student added successfully.");

        return;
    }


    /* ---------------- EDIT ---------------- */

    if (currentMode === "editing") {

        pendingAction = {
            type: "edit",
            student: newStudent
        };

        closeStudentForm();
        generateOTP();

        return;
    }

});


/* =========================================================
   OTP
   Math.random() creates a 6 digit OTP.
   The OTP is printed in the browser console.
   ========================================================= */

function generateOTP() {

    generatedOTP = Math.floor(100000 + Math.random() * 900000).toString();

    console.clear();
    console.log("====================================");
    console.log("SPMS ADMIN OTP");
    console.log("OTP:", generatedOTP);
    console.log("====================================");

    document.getElementById("otpInput").value = "";
    document.getElementById("otpError").textContent = "";

    otpModal.style.display = "flex";
}


/* =========================================================
   VERIFY OTP
   ========================================================= */

document.getElementById("verifyOtp").addEventListener("click", function () {

    var enteredOTP = document.getElementById("otpInput").value.trim();

    if (enteredOTP !== generatedOTP) {

        document.getElementById("otpError").textContent =
            "Wrong OTP. Check the browser console.";

        return;
    }

    if (pendingAction.type === "edit") {

        var index = students.findIndex(function (student) {
            return student.id === pendingAction.student.id;
        });

        if (index !== -1) {
            students[index] = pendingAction.student;
            saveStudents();
        }

        alert("Student updated successfully.");
    }

    if (pendingAction.type === "remove") {

        students = students.filter(function (student) {
            return selectedStudents.indexOf(student.id) === -1;
        });

        saveStudents();

        selectedStudents = [];

        alert("Selected students removed successfully.");
    }

    otpModal.style.display = "none";

    pendingAction = null;
    generatedOTP = null;

    currentMode = "normal";

    renderStudents();
    hideRemoveBar();
});


document.getElementById("cancelOtp").addEventListener("click", function () {

    otpModal.style.display = "none";

    pendingAction = null;
    generatedOTP = null;
});


/* =========================================================
   REMOVE MODE
   First click only selects students.
   Actual removal happens after OTP verification.
   ========================================================= */

removeStudentBtn.addEventListener("click", function () {

    if (!isAdmin) return;

    currentMode = "remove";
    selectedStudents = [];

    renderStudents();

    updateRemoveBar();
});


function toggleRemoveStudent(studentId) {

    var index = selectedStudents.indexOf(studentId);

    if (index === -1) {
        selectedStudents.push(studentId);
    } else {
        selectedStudents.splice(index, 1);
    }

    updateRemoveBar();
}


/* =========================================================
   REMOVE BAR
   ========================================================= */

function updateRemoveBar() {

    selectedCount.textContent = selectedStudents.length;
    removeNumber.textContent = selectedStudents.length;

    if (currentMode === "remove") {
        removeBar.classList.add("show");
    } else {
        removeBar.classList.remove("show");
    }
}

function hideRemoveBar() {
    removeBar.classList.remove("show");
}


/* =========================================================
   FINAL REMOVE
   ========================================================= */

document.getElementById("confirmRemove").addEventListener("click", function () {

    if (selectedStudents.length === 0) {
        alert("Select at least one student first.");
        return;
    }

    pendingAction = {
        type: "remove"
    };

    generateOTP();
});


document.getElementById("cancelRemove").addEventListener("click", function () {

    selectedStudents = [];
    currentMode = "normal";

    hideRemoveBar();

    renderStudents();
});


/* =========================================================
   RENDER STUDENTS
   ========================================================= */

function renderStudents() {

    studentList.innerHTML = "";

    var searchText = studentSearch.value.toLowerCase().trim();
    var selectedBranch = branchFilter.value;

    var filteredStudents = students.filter(function (student) {

        var matchesSearch =
            student.name.toLowerCase().includes(searchText) ||
            student.rollNo.toLowerCase().includes(searchText) ||
            student.branch.toLowerCase().includes(searchText);

        var matchesBranch =
            selectedBranch === "all" ||
            student.branch.toLowerCase() === selectedBranch.toLowerCase();

        return matchesSearch && matchesBranch;
    });


    studentCount.textContent = filteredStudents.length;

    updateBranchFilter();


    /* Empty state */

    if (filteredStudents.length === 0) {

        emptyState.style.display = "flex";
        showingText.textContent = "Showing 0 students";

        return;
    }

    emptyState.style.display = "none";


    /* Pagination */

    var totalPages = Math.ceil(filteredStudents.length / studentsPerPage);

    if (currentPage > totalPages) {
        currentPage = totalPages;
    }

    var start = (currentPage - 1) * studentsPerPage;
    var end = start + studentsPerPage;

    var pageStudents = filteredStudents.slice(start, end);


    for (var i = 0; i < pageStudents.length; i++) {

        var student = pageStudents[i];

        var row = document.createElement("div");
        row.className = "student-row";


        /* Student */

        var main = document.createElement("div");
        main.className = "student-main";

        var avatar = document.createElement("div");
        avatar.className = "student-avatar";
        avatar.textContent = getInitials(student.name);

        var name = document.createElement("div");
        name.className = "student-name";
        name.textContent = student.name;

        main.appendChild(avatar);
        main.appendChild(name);


        /* Roll */

        var roll = document.createElement("div");
        roll.className = "student-value";
        roll.textContent = student.rollNo;


        /* Branch */

        var branch = document.createElement("div");
        branch.className = "student-value";
        branch.textContent = student.branch;


        /* CGPA */

        var cgpa = document.createElement("div");
        cgpa.className = "student-value cgpa";
        cgpa.textContent = student.cgpa || "—";


        /* Status */

        var status = document.createElement("div");
        status.className = "status " + getStatusClass(student.placementStatus);
        status.textContent = student.placementStatus || "Not Eligible";


        /* Admission */

        var admission = document.createElement("div");
        admission.className = "student-value";
        admission.textContent = student.admissionYear || "—";


        /* Action */

        var action = document.createElement("div");
        action.className = "action-cell";


        /* NORMAL MODE */

        if (currentMode === "normal") {

            var button = document.createElement("button");
            button.className = "row-action";
            button.title = "View student details";
            button.innerHTML = '<i class="bi bi-three-dots-vertical"></i>';

            button.addEventListener("click", function (studentId) {

                return function () {
                    showStudentDetails(studentId);
                };

            }(student.id));

            action.appendChild(button);
        }


        /* EDIT MODE */

        if (currentMode === "edit") {

            var editButton = document.createElement("button");
            editButton.className = "edit-selection";
            editButton.title = "Edit " + student.name;
            editButton.innerHTML = '<i class="bi bi-pencil"></i>';

            editButton.addEventListener("click", function (studentId) {

                return function () {
                    openEditForm(studentId);
                };

            }(student.id));

            action.appendChild(editButton);
        }


        /* REMOVE MODE */

        if (currentMode === "remove") {

            var checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "remove-selection";
            checkbox.title = "Select " + student.name;

            checkbox.checked = selectedStudents.indexOf(student.id) !== -1;

            checkbox.addEventListener("change", function (studentId) {

                return function () {
                    toggleRemoveStudent(studentId);
                };

            }(student.id));

            action.appendChild(checkbox);
        }


        row.appendChild(main);
        row.appendChild(roll);
        row.appendChild(branch);
        row.appendChild(cgpa);
        row.appendChild(status);
        row.appendChild(admission);
        row.appendChild(action);

        studentList.appendChild(row);
    }


    showingText.textContent =
        "Showing " +
        (start + 1) +
        " to " +
        Math.min(end, filteredStudents.length) +
        " of " +
        filteredStudents.length +
        " students";

    document.getElementById("pageNumber").textContent = currentPage;
}


/* =========================================================
   INITIALS
   ========================================================= */

function getInitials(name) {

    var words = name.trim().split(" ");

    if (words.length === 1) {
        return words[0].charAt(0).toUpperCase();
    }

    return (
        words[0].charAt(0) +
        words[words.length - 1].charAt(0)
    ).toUpperCase();
}


/* =========================================================
   STATUS CLASS
   ========================================================= */

function getStatusClass(status) {

    if (!status) return "noteligible";

    var value = status.toLowerCase();

    if (value === "placed") return "placed";
    if (value === "unplaced") return "unplaced";

    return "noteligible";
}


/* =========================================================
   BRANCH FILTER
   ========================================================= */

function updateBranchFilter() {

    var currentValue = branchFilter.value;

    var branches = [];

    for (var i = 0; i < students.length; i++) {

        var branch = students[i].branch;

        if (branch && branches.indexOf(branch) === -1) {
            branches.push(branch);
        }
    }

    branchFilter.innerHTML = "";

    var allOption = document.createElement("option");
    allOption.value = "all";
    allOption.textContent = "All Branches";

    branchFilter.appendChild(allOption);

    for (var j = 0; j < branches.length; j++) {

        var option = document.createElement("option");

        option.value = branches[j];
        option.textContent = branches[j];

        branchFilter.appendChild(option);
    }

    if (branches.indexOf(currentValue) !== -1) {
        branchFilter.value = currentValue;
    } else {
        branchFilter.value = "all";
    }
}


/* =========================================================
   SEARCH
   ========================================================= */

studentSearch.addEventListener("input", function () {

    currentPage = 1;

    if (studentSearch.value.length > 0) {
        clearSearch.style.display = "block";
    } else {
        clearSearch.style.display = "none";
    }

    renderStudents();
});


clearSearch.addEventListener("click", function () {

    studentSearch.value = "";
    clearSearch.style.display = "none";

    currentPage = 1;

    renderStudents();
});


branchFilter.addEventListener("change", function () {

    currentPage = 1;

    renderStudents();
});


/* =========================================================
   PAGINATION
   ========================================================= */

document.getElementById("previousPage").addEventListener("click", function () {

    if (currentPage > 1) {
        currentPage--;
        renderStudents();
    }
});


document.getElementById("nextPage").addEventListener("click", function () {

    var searchText = studentSearch.value.toLowerCase().trim();

    var selectedBranch = branchFilter.value;

    var filteredCount = students.filter(function (student) {

        var matchesSearch =
            student.name.toLowerCase().includes(searchText) ||
            student.rollNo.toLowerCase().includes(searchText) ||
            student.branch.toLowerCase().includes(searchText);

        var matchesBranch =
            selectedBranch === "all" ||
            student.branch.toLowerCase() === selectedBranch.toLowerCase();

        return matchesSearch && matchesBranch;
    }).length;

    var totalPages = Math.ceil(filteredCount / studentsPerPage);

    if (currentPage < totalPages) {
        currentPage++;
        renderStudents();
    }
});


/* =========================================================
   STUDENT DETAILS
   Simple alert for now.
   This keeps the project beginner-friendly.
   ========================================================= */

function showStudentDetails(studentId) {

    var student = students.find(function (item) {
        return item.id === studentId;
    });

    if (!student) return;

    alert(
        "Student: " + student.name +
        "\nRoll No: " + student.rollNo +
        "\nBranch: " + student.branch +
        "\nCGPA: " + (student.cgpa || "—") +
        "\nPlacement: " + (student.placementStatus || "Not Eligible") +
        "\nDream Company: " + (student.dreamCompany || "—")
    );
}


/* =========================================================
   PROFILE ACTIONS
   ========================================================= */

function logoutUser() {

    localStorage.removeItem("currentUser");

    window.location.href = "index.html";
}


function switchUser() {

    localStorage.removeItem("currentUser");

    window.location.href = "signin.html";
}


/* =========================================================
   CLOSE MODALS WHEN CLICKING OUTSIDE
   ========================================================= */

studentModal.addEventListener("click", function (e) {

    if (e.target === studentModal) {
        closeStudentForm();
    }
});


otpModal.addEventListener("click", function (e) {

    if (e.target === otpModal) {
        otpModal.style.display = "none";

        pendingAction = null;
        generatedOTP = null;
    }
});


/* =========================================================
   START PAGE
   ========================================================= */

renderStudents();
